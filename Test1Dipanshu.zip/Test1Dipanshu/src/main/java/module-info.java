module com.example.test1dipanshu {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.test1dipanshu to javafx.fxml;
    exports com.example.test1dipanshu;
}