package com.example.test1dipanshu;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

public class HelloController {

    public TextField Username;
    public PasswordField Password;
    @FXML
    private Label welcomeText;
    String x = "dipanshu";
    String y = "123";

    Integer counter = 5;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("");


        String u = Username.getText();

        String p = Password.getText();

        if (x.equals(u) && y.equals(p)) {
            counter = 5;
            welcomeText.setText("Login Successful");

        } else if (x.equals(u) && y!= p) {

            if (counter > 0) {
                if (counter == 0) {
                    welcomeText.setText("Account Locked");
                } else {
                    counter--;
                    welcomeText.setText("You have " + counter + "Attempt left");
                }
            } else {
                welcomeText.setText("Account is Locked");


            }
            welcomeText.setText("Login Successful");

        } else {
            welcomeText.setText("Invalid Username or Password");
        }
    }
}




